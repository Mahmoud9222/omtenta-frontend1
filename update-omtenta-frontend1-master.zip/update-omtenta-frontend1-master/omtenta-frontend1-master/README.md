# Omtenta Frontend 1

## Uppgifterna
Vardera mapp innehåller en uppgift och ska göras enligt kodkomentarerna i html filen i mappen.

## När ni är klara
När ni är klara ska ni antingen komprimera projektet och skicka upp på studentportalen eller lämna in en github-länk (via text dokument) på studentportalen.
Ni lämnar in under "Inlämningar -> Deadline Nr2 -> INLÄMNING: Hemtenta".
